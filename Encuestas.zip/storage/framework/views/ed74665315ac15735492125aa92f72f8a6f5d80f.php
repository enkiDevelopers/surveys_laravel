	<?php $__env->startSection('content'); ?>
		<div style="width:80%;height:80%;align-content: center;margin: 0 auto">
			<canvas id="canvas"></canvas>
		</div>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.directive', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>