@extends('layouts.administrator')
@section('content')

<div></div>

@endsection