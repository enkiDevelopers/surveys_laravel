@extends('layouts.directive')
	@section('content')
		<div style="width:80%;height:80%;align-content: center;margin: 0 auto">
			<canvas id="canvas"></canvas>
		</div>
	@endsection
